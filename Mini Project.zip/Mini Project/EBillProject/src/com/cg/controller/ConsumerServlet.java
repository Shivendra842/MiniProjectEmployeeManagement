package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.ConsumerDetails;

import com.cg.service.BillService;
import com.cg.service.BillServiceImpl;

/**
 * Servlet implementation class ConsumerServlet
 */
@WebServlet("/ConsumerServlet")
public class ConsumerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       BillService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsumerServlet() {
        super();
        service=new BillServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(true);	
		String qStr=request.getParameter("action");
		if("searchConsumer".equals(qStr))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("search.jsp");
			dispatch.forward(request, response);
		}
		
		else if("listOfConsumer".equals(qStr))
		{
			
			ArrayList<ConsumerDetails> list=service.getAllConsumerDetails();
			session.setAttribute("consumerlist", list);
			System.out.println("List+" +list);
			RequestDispatcher dispatch=request.getRequestDispatcher("showAll.jsp");
			dispatch.forward(request, response);
		}
		else if("billDetails".equals(qStr))
		{
			//System.out.println("In bill Details.................");
			String number=request.getParameter("id");
			int id=Integer.parseInt(number);
			ArrayList <BillDetails> billDet=service.getBillDetails(id);
			session.setAttribute("bill", billDet);
			//System.out.println("In billDetails........"+billDet.get(0).getcNum());
			//session.setAttribute("cNumber", id);
			//System.out.println("In billDetails........"+id);
			if(billDet!=null)
			{
				session.setAttribute("bill", billDet);
				
				session.setAttribute("cId", id);
			RequestDispatcher dispatch=request.getRequestDispatcher("success.jsp");	
			dispatch.forward(request, response);
			}
			else
			{
				session.setAttribute("bill", id);
				RequestDispatcher dispatch=request.getRequestDispatcher("error.jsp");	
				dispatch.forward(request, response);	
			}
		}
		else if("addBill".equals(qStr))
		{
			System.out.println("In addDetails........");
			String number=request.getParameter("id");
			int cNum=Integer.parseInt(number);
			session.setAttribute("cNumber", cNum);
			System.out.println("In addDetails........");
			RequestDispatcher dispatch=request.getRequestDispatcher("insertBill.jsp");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);	
		String qStr=request.getParameter("action");
		if("generateBill".equals(qStr))
		{
			String Number=request.getParameter("cNumber");
			String lRead=request.getParameter("lRead");
			String cRead=request.getParameter("cRead");
			int cNum=Integer.parseInt(Number);
			Double lastRead=Double.parseDouble(lRead);
			Double curRead=Double.parseDouble(cRead);
			BillDetails bill=new BillDetails();
			bill.setcNum(cNum);
			bill.setCurReading(curRead);
			double unitConsumed=curRead-lastRead;
			if(unitConsumed<0)
			{
				RequestDispatcher dispatch =request.getRequestDispatcher("unitConsumedError.jsp");
				dispatch.forward(request, response);
			}
			else
			{
			double netAmount=unitConsumed*1.15+100;
			bill.setUnitConsumed(unitConsumed);
			bill.setNetAmount(netAmount);
			
			BillDetails ref=service.addBill(bill);
			if(ref!=null)
			{
				ConsumerDetails detail= service.getConsumerById(cNum);
				String name=detail.getcName();
				session.setAttribute("name", name);
				session.setAttribute("billdetails", ref);
				RequestDispatcher dispatch =request.getRequestDispatcher("insertSuccess.jsp");
				dispatch.forward(request, response);
		}
			}
			
		}
		else if("searchConsumer".equals(qStr))
		{
			ConsumerDetails ref=null;
			if(request.getParameter("cNumber").isEmpty())
			{
				RequestDispatcher dispatch =request.getRequestDispatcher("errorsearch.jsp");
				dispatch.forward(request, response);
			}
			else{
			String number=request.getParameter("cNumber");
			int cNum=Integer.parseInt(number);
			//System.out.println("the value is....................."+cNum);
			ref= service.getConsumerById(cNum);
			if(ref!=null)
			{
				session.setAttribute("consu", ref);
					RequestDispatcher dispatch =request.getRequestDispatcher("DisplayConsumer.jsp");
					dispatch.forward(request, response);
			}
			else
			{
				session.setAttribute("id", cNum);
				RequestDispatcher dispatch =request.getRequestDispatcher("ConsumerNotFound.jsp");
				dispatch.forward(request, response);
			}
			
			
		}
		}
	}

}
