package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.ConsumerDetails;





public interface BillDao {
	public BillDetails addBill(BillDetails bill);
	public ArrayList<BillDetails> getBillDetails(int id);
	public ConsumerDetails getConsumerById(int cNum);
	public ArrayList<ConsumerDetails> getAllConsumerDetails();
}
