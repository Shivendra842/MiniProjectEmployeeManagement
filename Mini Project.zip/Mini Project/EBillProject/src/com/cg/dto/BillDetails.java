package com.cg.dto;

import java.time.LocalDate;

public class BillDetails {
	int billNo;
	int cNum;
	double curReading;
	double unitConsumed;
	double netAmount;
	LocalDate date;
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public int getcNum() {
		return cNum;
	}
	public void setcNum(int cNum) {
		this.cNum = cNum;
	}
	public double getCurReading() {
		return curReading;
	}
	public void setCurReading(double curReading) {
		this.curReading = curReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public BillDetails(int billNo, int cNum, double curReading,
			double unitConsumed, double netAmount,LocalDate date) {
		super();
		this.billNo = billNo;
		this.cNum = cNum;
		this.curReading = curReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.date=date;
	}
	@Override
	public String toString() {
		return "BillDetails [billNo=" + billNo + ", cNum=" + cNum
				+ ", curReading=" + curReading + ", unitConsumed="
				+ unitConsumed + ", netAmount=" + netAmount + ", date=" + date
				+ "]";
	}
	public BillDetails() {
		super();
	}
}
