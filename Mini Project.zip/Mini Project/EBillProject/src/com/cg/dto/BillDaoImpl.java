package com.cg.dto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;







import com.cg.dao.BillDao;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class BillDaoImpl implements BillDao{

	Connection con;
	
	public BillDaoImpl() {
		
		con=DBUtil.getConnection();
				
	}
	@Override
	public BillDetails addBill(BillDetails bill) {
		
	//	BillDetails ref=null;
		String qry="INSERT INTO BillDetails VALUES(seq_bill_num .nextval,?,?,?,?,sysdate)";
		try
		{
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1,bill.getcNum());
			pstmt.setDouble(2, bill.getCurReading());
			pstmt.setDouble(3, bill.getUnitConsumed());
			pstmt.setDouble(4, bill.getNetAmount());
			
			int row =pstmt.executeUpdate();
			System.out.println(row);
			if(row>0)
			{
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return bill;
	}

	@Override
	public ArrayList<BillDetails> getBillDetails(int id) {
		
		String qry="SELECT * FROM BillDetails WHERE consumer_num=?";
		ArrayList<BillDetails>list=null;
				list=new ArrayList<BillDetails>();
		try
		{
		PreparedStatement stmt=con.prepareStatement(qry);
		stmt.setInt(1,id);
		//System.out.println("In query function.................");
		
		
			ResultSet rs=stmt.executeQuery();
			//System.out.println("after executequery function.................");
			if(rs.next()==false)
			{
				list=null;
			}
			else
			{
			do
			{
				int bNum=rs.getInt(1);
				int cNum=rs.getInt(2);
				//System.out.println("after cNUm.................");
				double cRead=rs.getFloat(3);
				double cCon=rs.getFloat(4);
				double amt=rs.getFloat(5);
				//System.out.println("after amt.................");
				//System.out.println(id);
				Date sqlDate=rs.getDate(6);
				//System.out.println("after date.................");
				LocalDate date=MyStringDateUtil.fromSqlToLocalDate(sqlDate);
			//	System.out.println("after fromSqlToLocalDate.................");
				BillDetails bill=new BillDetails(bNum,cNum,cRead,cCon,amt,date);
				list.add(bill);
			}while(rs.next());
			
			}
			
				
			
	//	System.out.println("after date.................");
		//	System.out.println("List+" +list);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ConsumerDetails getConsumerById(int cNum) 
	{
		ConsumerDetails ref=null;
		String qry="SELECT * FROM Consumers WHERE consumer_num=?";
		try
		{
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1,cNum);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				String name=rs.getString(2);
				String addr=rs.getString(3);
				ref=new ConsumerDetails(cNum, name,addr);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
		
	}
	@Override
	public ArrayList<ConsumerDetails> getAllConsumerDetails() 
	{
		String qry="SELECT * FROM Consumers";
		ArrayList<ConsumerDetails>list=new ArrayList<ConsumerDetails>();
		System.out.println(qry);
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(qry);
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String addr=rs.getString(3);
				System.out.println(name);
				ConsumerDetails con=new ConsumerDetails(id, name, addr);
				list.add(con);
			}
			System.out.println("List+" +list);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;


	}

}
