package com.cg.dto;

public class ConsumerDetails {
	int cNum;
	String cName;
	String cAddr;
	public int getcNum() {
		return cNum;
	}
	public void setcNum(int cNum) {
		this.cNum = cNum;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcAddr() {
		return cAddr;
	}
	public void setcAddr(String cAddr) {
		this.cAddr = cAddr;
	}
	public ConsumerDetails(int cNum, String cName, String cAddr) {
		super();
		this.cNum = cNum;
		this.cName = cName;
		this.cAddr = cAddr;
	}
	public ConsumerDetails() {
		super();
	}
	@Override
	public String toString() {
		return "ConsumerDetails [cNum=" + cNum + ", cName=" + cName
				+ ", cAddr=" + cAddr + "]";
	}
	
	

}
