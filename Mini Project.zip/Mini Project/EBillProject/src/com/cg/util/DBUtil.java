package com.cg.util;

import java.sql.*;
import java.io.FileReader;
import java.io.IOException;

import java.sql.DriverManager;
import java.util.Properties;

public class DBUtil {
	static Connection con;
	
	static 
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G";
			String user="Lab2Etrg15";
			String pass="lab2eoracle";
			con=DriverManager.getConnection(url,user,pass);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
	


	


	
	
	

}
