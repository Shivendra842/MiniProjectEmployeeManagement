package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.BillDao;
import com.cg.dto.BillDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.ConsumerDetails;

public class BillServiceImpl implements BillService{
	
	BillDao dao;
	public BillServiceImpl() {
		dao=new BillDaoImpl();
	}

	@Override
	public BillDetails addBill(BillDetails bill) {
		// TODO Auto-generated method stub
		return dao.addBill(bill);
	}

	@Override
	public ArrayList<BillDetails> getBillDetails(int id) {
		// TODO Auto-generated method stub
		return dao.getBillDetails(id);
	}

	@Override
	public ConsumerDetails getConsumerById(int cNum) {
		// TODO Auto-generated method stub
		return dao.getConsumerById(cNum);
	}

	@Override
	public ArrayList<ConsumerDetails> getAllConsumerDetails() {
		// TODO Auto-generated method stub
		return dao.getAllConsumerDetails();
	}

}
