package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       EmployeeService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        service=new EmployeeServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	HttpSession session=request.getSession(true);	
	String qStr=request.getParameter("action");
	if("insert".equals(qStr))
	{
		RequestDispatcher dispatch=request.getRequestDispatcher("insert.jsp");
		dispatch.forward(request, response);
	}
	else if("displayById".equals(qStr))
	{
		System.out.println("In display By Id...............");
		RequestDispatcher dispatch=request.getRequestDispatcher("searchById.jsp");
		dispatch.forward(request, response);
	
	}
	else if("update".equals(qStr))
	{
		String empId=request.getParameter("id");
		int eId=Integer.parseInt(empId);
		Employee emp=service.getEmployeeById(eId);
		session.setAttribute("emp", emp);
		RequestDispatcher dispatch=request.getRequestDispatcher("updateData.jsp");
		dispatch.forward(request, response);
	}
	else if("delete".equals(qStr))
	{
		//System.out.println("In Search By Id...............");
		String empId=request.getParameter("id");
		int eId=Integer.parseInt(empId);
		Employee emp=service.getEmployeeById(eId);
		boolean flag=service.deleteEmployee(eId);
		session.setAttribute("empById", emp);
		if(flag)
		{
		RequestDispatcher dispatch=request.getRequestDispatcher("deletesuccess.jsp");	
		dispatch.forward(request, response);
		}
	}
	
	else if("displayAll".equals(qStr))
	{
		
		ArrayList<Employee> list=service.getAllEmployees();
		session.setAttribute("emplist", list);
		System.out.println("List+" +list);
		RequestDispatcher dispatch=request.getRequestDispatcher("searchAll.jsp");
		dispatch.forward(request, response);
	}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(false);	
		String qStr=request.getParameter("action");
		if("insertEmp".equals(qStr))
		{
			String name=request.getParameter("eName");
			String addr=request.getParameter("addr");
			String sal=request.getParameter("eSal");
			int eSal=Integer.parseInt(sal);
			Employee emp=new Employee();
			emp.setEmpName(name);
			emp.setEmpSal(eSal);
			emp.setEmpAddr(addr);
			Employee ref=service.addEmployee(emp);
			if(ref!=null)
			{
				session.setAttribute("emp", ref);
				RequestDispatcher dispatch =request.getRequestDispatcher("insertSuccess.jsp");
				dispatch.forward(request, response);
			}
			
		}
		else if("searchById".equals(qStr))
		{
			System.out.println("In Search By Id...............");
			String empId=request.getParameter("id");
			int eId=Integer.parseInt(empId);
			Employee emp=service.getEmployeeById(eId);
			session.setAttribute("empById", emp);
			RequestDispatcher dispatch=request.getRequestDispatcher("success.jsp");	
			dispatch.forward(request, response);
		}
		else if("updateEmp".equals(qStr))
		{
			String empId=request.getParameter("id");
			int eId=Integer.parseInt(empId);
			String name=request.getParameter("eName");
			String addr=request.getParameter("addr");
			String sal=request.getParameter("eSal");
			int eSal=Integer.parseInt(sal);
			Employee emp=new Employee();
			emp.setEmpName(name);
			emp.setEmpSal(eSal);
			emp.setEmpAddr(addr);
			emp.setEmpId(eId);
			//Employee emp=service.getEmployeeById(eId);
			boolean flag=service.update(emp);
			//session.setAttribute("empById", emp);
			
			RequestDispatcher dispatch=request.getRequestDispatcher("index.jsp");	
			dispatch.forward(request, response);
		}
	}

}
